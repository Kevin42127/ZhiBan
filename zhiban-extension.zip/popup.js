const API_BASE_URL = 'https://zhiban.vercel.app/api/chat';
const STORAGE_KEY = 'zhiban_conversation_history';
const MAX_VISIBLE_MESSAGES = 50;
const MAX_HISTORY_MESSAGES = 20;
const CLIENT_API_KEY = 'mq2Egl$@~]DRQ^}5#6rX;8t^-PG0Tr]G)A7%kgHgojz]pMngTB';

let conversationHistory = [];
let visibleStartIndex = 0;
let visibleEndIndex = 0;

const messagesContainer = document.getElementById('messages');
const messageInput = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');
const clearBtn = document.getElementById('clearBtn');
const confirmDialogOverlay = document.getElementById('confirmDialogOverlay');
const confirmDialogTitle = document.getElementById('confirmDialogTitle');
const confirmDialogMessage = document.getElementById('confirmDialogMessage');
const confirmDialogConfirm = document.getElementById('confirmDialogConfirm');
const confirmDialogCancel = document.getElementById('confirmDialogCancel');
const chatContainer = document.getElementById('chatContainer');
const emptyState = document.getElementById('emptyState');

async function getApiUrl() {
  const result = await chrome.storage.sync.get(['apiUrl']);
  return result.apiUrl || API_BASE_URL;
}

async function saveConversationHistory() {
  try {
    await chrome.storage.local.set({ [STORAGE_KEY]: conversationHistory });
  } catch (error) {
    console.error('Failed to save conversation history:', error);
  }
}

function showWelcomeMessage() {
  const welcomeText = '你好，我可以幫你什麼忙？';
  const welcomeDiv = addMessage(welcomeText, 'ai');
  welcomeDiv.classList.add('welcome-message');
  welcomeDiv.setAttribute('data-welcome', 'true');
}

function removeWelcomeMessage() {
  const welcomeMsg = messagesContainer.querySelector('.welcome-message');
  if (welcomeMsg) {
    welcomeMsg.remove();
  }
}

async function loadConversationHistory() {
  try {
    const result = await chrome.storage.local.get([STORAGE_KEY]);
    if (result[STORAGE_KEY] && Array.isArray(result[STORAGE_KEY]) && result[STORAGE_KEY].length > 0) {
      conversationHistory = result[STORAGE_KEY];
      renderHistory();
    } else {
      conversationHistory = [];
      showEmptyState();
    }
  } catch (error) {
    console.error('Failed to load conversation history:', error);
    conversationHistory = [];
    showEmptyState();
  }
}

function showEmptyState() {
  if (emptyState) {
    emptyState.style.display = 'flex';
  }
  if (messagesContainer) {
    messagesContainer.style.display = 'none';
  }
}

function hideEmptyState() {
  if (emptyState) {
    emptyState.style.display = 'none';
  }
  if (messagesContainer) {
    messagesContainer.style.display = 'flex';
  }
}

function renderHistory() {
  messagesContainer.innerHTML = '';
  
  const totalMessages = conversationHistory.length;
  if (totalMessages === 0) {
    showEmptyState();
    return;
  }
  
  hideEmptyState();
  
  let startIndex = 0;
  if (totalMessages > MAX_VISIBLE_MESSAGES) {
    startIndex = totalMessages - MAX_VISIBLE_MESSAGES;
    visibleStartIndex = startIndex;
    visibleEndIndex = totalMessages;
  } else {
    visibleStartIndex = 0;
    visibleEndIndex = totalMessages;
  }
  
  for (let i = startIndex; i < totalMessages; i++) {
    const msg = conversationHistory[i];
    if (msg && msg.content !== undefined && msg.role) {
      let role = msg.role;
      if (role === 'assistant') {
        role = 'ai';
      }
      const messageDiv = addMessage(msg.content, role);
      if (messageDiv) {
        const avatar = messageDiv.querySelector('.message-avatar');
        if (!avatar) {
          const avatarDiv = document.createElement('div');
          avatarDiv.className = 'message-avatar';
          const avatarIcon = document.createElement('span');
          avatarIcon.className = 'material-icons';
          avatarIcon.textContent = role === 'user' ? 'person' : 'auto_awesome';
          avatarDiv.appendChild(avatarIcon);
          const contentDiv = messageDiv.querySelector('.message-content');
          if (contentDiv) {
            messageDiv.insertBefore(avatarDiv, contentDiv);
          } else {
            messageDiv.insertBefore(avatarDiv, messageDiv.firstChild);
          }
        }
      }
    }
  }
  
  scrollToBottom();
}

function showConfirmDialog(title, message) {
  return new Promise((resolve) => {
    confirmDialogTitle.textContent = title;
    confirmDialogMessage.textContent = message;
    confirmDialogOverlay.style.display = 'flex';
    
    const handleConfirm = () => {
      confirmDialogOverlay.style.display = 'none';
      confirmDialogConfirm.removeEventListener('click', handleConfirm);
      confirmDialogCancel.removeEventListener('click', handleCancel);
      confirmDialogOverlay.removeEventListener('click', handleOverlayClick);
      resolve(true);
    };
    
    const handleCancel = () => {
      confirmDialogOverlay.style.display = 'none';
      confirmDialogConfirm.removeEventListener('click', handleConfirm);
      confirmDialogCancel.removeEventListener('click', handleCancel);
      confirmDialogOverlay.removeEventListener('click', handleOverlayClick);
      resolve(false);
    };
    
    const handleOverlayClick = (e) => {
      if (e.target === confirmDialogOverlay) {
        handleCancel();
      }
    };
    
    confirmDialogConfirm.addEventListener('click', handleConfirm);
    confirmDialogCancel.addEventListener('click', handleCancel);
    confirmDialogOverlay.addEventListener('click', handleOverlayClick);
  });
}

async function clearAllMessages() {
  if (conversationHistory.length === 0) return;
  
  const confirmed = await showConfirmDialog('確認清空', '確定要清空所有對話嗎？');
  if (confirmed) {
    conversationHistory = [];
    messagesContainer.innerHTML = '';
    await saveConversationHistory();
    showEmptyState();
  }
}

function addMessage(content, role, messageDiv = null) {
  if (role === 'assistant') {
    role = 'ai';
  }
  
  if (!messageDiv) {
    messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}`;
    
    if (role === 'ai') {
      const avatarDiv = document.createElement('div');
      avatarDiv.className = 'message-avatar';
      const avatarIcon = document.createElement('span');
      avatarIcon.className = 'material-icons';
      avatarIcon.textContent = 'auto_awesome';
      avatarDiv.appendChild(avatarIcon);
      messageDiv.appendChild(avatarDiv);
    }
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    const formattedContent = formatTextContent(content);
    contentDiv.innerHTML = formattedContent;
    messageDiv.appendChild(contentDiv);
    
    if (role === 'user') {
      const avatarDiv = document.createElement('div');
      avatarDiv.className = 'message-avatar';
      const avatarIcon = document.createElement('span');
      avatarIcon.className = 'material-icons';
      avatarIcon.textContent = 'person';
      avatarDiv.appendChild(avatarIcon);
      messageDiv.appendChild(avatarDiv);
    }
    
    messagesContainer.appendChild(messageDiv);
  } else {
    let avatarDiv = messageDiv.querySelector('.message-avatar');
    if (!avatarDiv) {
      avatarDiv = document.createElement('div');
      avatarDiv.className = 'message-avatar';
      const avatarIcon = document.createElement('span');
      avatarIcon.className = 'material-icons';
      avatarIcon.textContent = role === 'user' ? 'person' : 'auto_awesome';
      avatarDiv.appendChild(avatarIcon);
      const contentDiv = messageDiv.querySelector('.message-content');
      if (contentDiv) {
        if (role === 'ai') {
          messageDiv.insertBefore(avatarDiv, contentDiv);
        } else {
          messageDiv.appendChild(avatarDiv);
        }
      } else {
        if (role === 'ai') {
          messageDiv.insertBefore(avatarDiv, messageDiv.firstChild);
        } else {
          messageDiv.appendChild(avatarDiv);
        }
      }
    } else {
      const avatarIcon = avatarDiv.querySelector('.material-icons');
      if (avatarIcon) {
        avatarIcon.textContent = role === 'user' ? 'person' : 'auto_awesome';
      } else {
        const newAvatarIcon = document.createElement('span');
        newAvatarIcon.className = 'material-icons';
        newAvatarIcon.textContent = role === 'user' ? 'person' : 'auto_awesome';
        avatarDiv.appendChild(newAvatarIcon);
      }
    }
    
    let contentDiv = messageDiv.querySelector('.message-content');
    if (!contentDiv) {
      contentDiv = document.createElement('div');
      contentDiv.className = 'message-content';
      const avatarDiv = messageDiv.querySelector('.message-avatar');
      if (avatarDiv && role === 'ai') {
        messageDiv.insertBefore(contentDiv, avatarDiv.nextSibling);
      } else {
        messageDiv.appendChild(contentDiv);
      }
    }
    const formattedContent = formatTextContent(content);
    contentDiv.innerHTML = formattedContent;
    
    if (!messageDiv.className.includes(role)) {
      messageDiv.className = `message ${role}`;
    }
  }
  
  scrollToBottom();
  return messageDiv;
}

function formatTextContent(text) {
  if (!text) return '';
  
  let formatted = text;
  
  formatted = addSpaceBetweenChineseAndEnglish(formatted);
  formatted = optimizePunctuationLineBreak(formatted);
  formatted = cleanMultipleEmptyLines(formatted);
  
  const paragraphs = formatted.split('\n\n').map(p => p.trim()).filter(p => p.length > 0);
  const result = [];
  
  for (let i = 0; i < paragraphs.length; i++) {
    const paragraph = paragraphs[i];
    const lines = paragraph.split('\n').map(line => line.trim()).filter(line => line.length > 0);
    
    if (lines.length === 0) continue;
    
    const bulletItems = [];
    const numberedItems = [];
    const regularLines = [];
    let inBulletList = false;
    let inNumberedList = false;
    
    for (let j = 0; j < lines.length; j++) {
      const line = lines[j];
      const bulletMatch = line.match(/^[-•]\s+(.+)$/);
      const numberedMatch = line.match(/^\d+\.\s+(.+)$/);
      
      if (bulletMatch) {
        if (!inBulletList && (bulletItems.length > 0 || regularLines.length > 0)) {
          if (regularLines.length > 0) {
            result.push(`<p>${regularLines.join('<br>')}</p>`);
            regularLines.length = 0;
          }
          if (bulletItems.length > 0) {
            result.push(formatBulletList(bulletItems));
            bulletItems.length = 0;
          }
        }
        bulletItems.push(bulletMatch[1]);
        inBulletList = true;
        inNumberedList = false;
      } else if (numberedMatch) {
        if (!inNumberedList && (numberedItems.length > 0 || regularLines.length > 0)) {
          if (regularLines.length > 0) {
            result.push(`<p>${regularLines.join('<br>')}</p>`);
            regularLines.length = 0;
          }
          if (numberedItems.length > 0) {
            result.push(formatNumberedList(numberedItems));
            numberedItems.length = 0;
          }
        }
        numberedItems.push(numberedMatch[1]);
        inNumberedList = true;
        inBulletList = false;
      } else {
        if (inBulletList && bulletItems.length > 0) {
          result.push(formatBulletList(bulletItems));
          bulletItems.length = 0;
          inBulletList = false;
        }
        if (inNumberedList && numberedItems.length > 0) {
          result.push(formatNumberedList(numberedItems));
          numberedItems.length = 0;
          inNumberedList = false;
        }
        regularLines.push(line);
      }
    }
    
    if (bulletItems.length > 0) {
      result.push(formatBulletList(bulletItems));
    }
    if (numberedItems.length > 0) {
      result.push(formatNumberedList(numberedItems));
    }
    if (regularLines.length > 0) {
      const optimized = optimizeLongText(regularLines.join('\n'));
      result.push(`<p>${optimized.replace(/\n/g, '<br>')}</p>`);
    }
  }
  
  return result.join('');
}

function formatBulletList(items) {
  const listItems = items.map(item => `<li>${item}</li>`).join('');
  return `<ul>${listItems}</ul>`;
}

function formatNumberedList(items) {
  const listItems = items.map(item => `<li>${item}</li>`).join('');
  return `<ol>${listItems}</ol>`;
}

function addSpaceBetweenChineseAndEnglish(text) {
  return text
    .replace(/([\u4e00-\u9fff])([a-zA-Z])/g, '$1 $2')
    .replace(/([a-zA-Z])([\u4e00-\u9fff])/g, '$1 $2')
    .replace(/([\u4e00-\u9fff])([0-9])/g, '$1 $2')
    .replace(/([0-9])([\u4e00-\u9fff])/g, '$1 $2');
}

function optimizePunctuationLineBreak(text) {
  const punctuation = /([。，、；：！？）】」』〉》])/g;
  return text.replace(punctuation, '$1\u200B');
}

function cleanMultipleEmptyLines(text) {
  return text.replace(/\n{3,}/g, '\n\n');
}

function optimizeLongText(text) {
  if (text.length > 500) {
    const sentences = text.split(/([。！？\n])/);
    let result = '';
    let currentLength = 0;
    
    for (let i = 0; i < sentences.length; i++) {
      const sentence = sentences[i];
      if (currentLength + sentence.length > 80 && currentLength > 0) {
        result += '\n';
        currentLength = 0;
      }
      result += sentence;
      currentLength += sentence.length;
    }
    
    return result;
  }
  return text;
}

function scrollToBottom() {
  const chatContainer = document.querySelector('.chat-container');
  if (chatContainer) {
    chatContainer.scrollTo({
      top: chatContainer.scrollHeight,
      behavior: 'smooth'
    });
  }
}

function showLoading() {
  sendBtn.disabled = true;
  messageInput.disabled = true;
}

function hideLoading() {
  sendBtn.disabled = false;
  messageInput.disabled = false;
}

function detectLanguage(text) {
  const chineseRegex = /[\u4e00-\u9fff]/;
  const englishRegex = /[a-zA-Z]/;
  
  if (chineseRegex.test(text)) {
    return 'zh-TW';
  }
  
  if (englishRegex.test(text)) {
    return 'en';
  }
  
  return null;
}

function detectLanguageFromHistory(history) {
  if (!history || history.length === 0) {
    return null;
  }
  
  const chineseRegex = /[\u4e00-\u9fff]/;
  const englishRegex = /[a-zA-Z]/;
  
  let chineseCount = 0;
  let englishCount = 0;
  
  for (const msg of history) {
    const content = msg.content || '';
    if (chineseRegex.test(content)) {
      chineseCount++;
    } else if (englishRegex.test(content)) {
      englishCount++;
    }
  }
  
  if (chineseCount > englishCount) {
    return 'zh-TW';
  } else if (englishCount > chineseCount) {
    return 'en';
  }
  
  return null;
}

function getLanguageForMessage(message, history) {
  const detectedLanguage = detectLanguage(message);
  
  if (detectedLanguage) {
    return detectedLanguage;
  }
  
  const historyLanguage = detectLanguageFromHistory(history);
  
  if (historyLanguage) {
    return historyLanguage;
  }
  
  return 'zh-TW';
}

function showError(message) {
  const errorDiv = document.createElement('div');
  errorDiv.className = 'error-message';
  
  const lines = message.split('\n');
  lines.forEach((line, index) => {
    if (line.trim()) {
      const lineDiv = document.createElement('div');
      if (line.startsWith('💡') || line.startsWith('⏱️')) {
        lineDiv.className = 'error-line-icon';
      } else if (line.startsWith('•')) {
        lineDiv.className = 'error-line-item';
      } else if (index === 0) {
        lineDiv.className = 'error-line-title';
      } else {
        lineDiv.className = 'error-line';
      }
      lineDiv.textContent = line;
      errorDiv.appendChild(lineDiv);
    } else {
      const spacer = document.createElement('div');
      spacer.className = 'error-spacer';
      errorDiv.appendChild(spacer);
    }
  });
  
  messagesContainer.appendChild(errorDiv);
  messagesContainer.scrollTop = messagesContainer.scrollHeight;
  
  setTimeout(() => {
    errorDiv.remove();
  }, 10000);
}

async function sendMessage(message) {
  if (!message.trim()) return;

  hideEmptyState();
  addMessage(message, 'user');
  conversationHistory.push({ role: 'user', content: message });
  await saveConversationHistory();
  
  messageInput.value = '';
  messageInput.style.height = 'auto';
  showLoading();

  const aiMessageDiv = addMessage('', 'ai');
  let aiMessageContent = '';

  try {
    const apiUrl = await getApiUrl();
    const currentHistory = conversationHistory.slice(0, -1);
    const limitedHistory = currentHistory.slice(-MAX_HISTORY_MESSAGES);
    const language = getLanguageForMessage(message, limitedHistory);
    
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': CLIENT_API_KEY,
      },
      body: JSON.stringify({
        message: message,
        history: limitedHistory,
        language: language
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      let errorData;
      try {
        errorData = JSON.parse(errorText);
      } catch {
        errorData = { error: errorText || '請求失敗' };
      }
      
      if (response.status === 429) {
        const retryAfter = errorData.retryAfter || 60;
        const minutes = Math.floor(retryAfter / 60);
        const seconds = retryAfter % 60;
        let timeText = '';
        if (minutes > 0) {
          timeText = `${minutes} 分 ${seconds} 秒`;
        } else {
          timeText = `${seconds} 秒`;
        }
        
        let reasonText = errorData.message || '請稍後再試';
        if (reasonText.includes('請求過於頻繁')) {
          reasonText = '請稍後再試';
        }
        
        throw new Error(`請求過於頻繁\n\n${reasonText}\n\n⏱️ ${timeText} 後可重試\n\n💡 使用限制：\n• 每 10 秒：最多 3 次\n• 每分鐘：最多 20 次\n• 每小時：最多 150 次\n• 每天：最多 2000 次`);
      }
      
      throw new Error(errorData.error || errorData.message || '請求失敗');
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.content) {
                aiMessageContent += data.content;
                addMessage(aiMessageContent, 'ai', aiMessageDiv);
                scrollToBottom();
              }
              if (data.done) {
                conversationHistory.push({ role: 'ai', content: aiMessageContent });
                await saveConversationHistory();
                scrollToBottom();
                break;
              }
            } catch (e) {
              console.error('Parse error:', e);
            }
          }
        }
      }
    } catch (streamError) {
      console.error('Stream reading error:', streamError);
      if (aiMessageContent.length > 0) {
        conversationHistory.push({ role: 'ai', content: aiMessageContent });
        await saveConversationHistory();
      } else {
        throw new Error('連線中斷，請重試');
      }
    }
  } catch (error) {
    console.error('Error:', error);
    let errorMessage = error.message;
    
    if (error.message.includes('模型回應格式錯誤') || error.message.includes('Parsing failed')) {
      errorMessage = 'AI 回應格式異常\n\n請稍後再試或重新發送訊息';
    } else if (error.message.includes('請求過於頻繁')) {
      errorMessage = error.message;
    } else if (error.message.includes('Stream error') || error.message.includes('stream') || error.message.includes('連線中斷')) {
      errorMessage = '連線中斷\n\n請檢查網路連線後重試';
    } else if (!errorMessage.startsWith('錯誤: ')) {
      errorMessage = `錯誤: ${errorMessage}`;
    }
    
    showError(errorMessage);
    
    if (aiMessageDiv && aiMessageDiv.parentNode) {
      aiMessageDiv.remove();
    }
    conversationHistory.pop();
    await saveConversationHistory();
  } finally {
    hideLoading();
    messageInput.focus();
  }
}

sendBtn.addEventListener('click', () => {
  const message = messageInput.value.trim();
  if (message) {
    sendMessage(message);
  }
});

function adjustTextareaHeight() {
  messageInput.style.height = 'auto';
  const scrollHeight = messageInput.scrollHeight;
  const maxHeight = 120;
  messageInput.style.height = Math.min(scrollHeight, maxHeight) + 'px';
}

messageInput.addEventListener('input', adjustTextareaHeight);

messageInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    const message = messageInput.value.trim();
    if (message) {
      sendMessage(message);
      messageInput.style.height = 'auto';
    }
  }
});

clearBtn.addEventListener('click', () => {
  clearAllMessages();
});

document.querySelectorAll('.example-question').forEach(btn => {
  btn.addEventListener('click', () => {
    const question = btn.getAttribute('data-question');
    if (question) {
      messageInput.value = question;
      messageInput.style.height = 'auto';
      messageInput.style.height = `${Math.min(messageInput.scrollHeight, 180)}px`;
      sendMessage(question);
    }
  });
});

loadConversationHistory();
messageInput.focus();

